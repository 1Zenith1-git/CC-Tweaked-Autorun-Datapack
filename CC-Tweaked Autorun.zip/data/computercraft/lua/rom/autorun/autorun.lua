-- Autorun manager for ComputerCraft
-- Runs all files in the computer's root ending with _autorun.lua

local function ends_with(str, ending)
   return ending == "" or str:sub(-#ending) == ending
end

local function find_autorun_files()
   local autorun_files = {}
   local files = fs.list("")
   for _, file in ipairs(files) do
       if not fs.isDir(file) and ends_with(file, "_autorun.lua") then
           table.insert(autorun_files, file)
       end
   end
   return autorun_files
end

local function run_autorun_scripts()
   local scripts = find_autorun_files()
   table.sort(scripts)
   for _, script in ipairs(scripts) do
       print("> running: " .. script)
       local ok, err = parallel.waitForAny(function()
           shell.run(script)
       end)
       if not ok then
           printError("Error running " .. script .. ": " .. tostring(err))
       end
   end
end

run_autorun_scripts()